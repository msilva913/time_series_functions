# -*- coding: utf-8 -*-
"""
Created on Wed Sep  9 14:33:04 2020

@author: Administrator
"""

from setuptools import setup, find_packages
setup(name='time_series_functions',
      author='Mario Rafael Silva',
      version='0.1',
      packages = find_packages(),
      )